let allProducts = [];
let favoriteIds = JSON.parse(localStorage.getItem('favorites') || '[]');
let currentPage = 1;
const itemsPerPage = 10;

async function startApp() {
  const seriesFilter = document.getElementById("seriesFilter");
  const inStockFilter = document.getElementById("inStockFilter");

  function toggleFavorite(id) {
    id = String(id);
    if (favoriteIds.includes(id)) {
      favoriteIds = favoriteIds.filter(favId => favId !== id);
    } else {
      favoriteIds.push(id);
    }
    localStorage.setItem('favorites', JSON.stringify(favoriteIds));
    filterAndSortProducts();
  }

  function renderProducts(products) {
    const container = document.getElementById('products');
    container.innerHTML = '';
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const currentItems = products.slice(start, end);

    currentItems.forEach(product => {
      const isFavorite = favoriteIds.includes(String(product.id));
      const div = document.createElement('div');
      div.className = 'product';
      div.innerHTML = `
        <div class="badge">${product.badge || ''}</div>
        <a href="product.html?id=${product.id}">
          <img src="/images/${product.image}" alt="${product.title}" />
          <h4>${product.title}</h4>
        </a>
        <p>${product.price} грн</p>
        <button class="fav" onclick="toggleFavorite('${product.id}')">
          ${isFavorite ? 'Улюблене' : 'В улюблене'}
        </button>
      `;
      container.appendChild(div);
    });

    renderPagination(products.length);
  }

  function renderPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const container = document.getElementById('pagination');
    container.innerHTML = '';
    for (let i = 1; i <= totalPages; i++) {
      const btn = document.createElement('button');
      btn.textContent = i;
      if (i === currentPage) btn.style.fontWeight = 'bold';
      btn.addEventListener('click', () => {
        currentPage = i;
        filterAndSortProducts();
      });
      container.appendChild(btn);
    }
  }

  function applyFilters(products) {
    return products.filter(p => {
      const matchSeries = !seriesFilter.value || p.series === seriesFilter.value;
      const matchStock = !inStockFilter.checked || p.inStock;
      return matchSeries && matchStock;
    });
  }

  function filterAndSortProducts() {
    const query = document.getElementById('searchInput')?.value?.toLowerCase() || "";
    const sort = document.getElementById('sortSelect').value;
    const favOnly = document.getElementById('favOnlyToggle').checked;

    let filtered = allProducts
      .filter(p => p.title.toLowerCase().includes(query))
      .filter(p => !favOnly || favoriteIds.includes(String(p.id)));

    filtered = applyFilters(filtered);

    if (sort === 'asc') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sort === 'desc') {
      filtered.sort((a, b) => b.price - a.price);
    }

    renderProducts(filtered);
  }

  function populateFilterOptions(products) {
    const seriesSet = new Set();
    products.forEach(p => {
      if (p.series) seriesSet.add(p.series);
    });

    for (const series of seriesSet) {
      const opt = document.createElement("option");
      opt.value = series;
      opt.textContent = series;
      seriesFilter.appendChild(opt);
    }
  }

  function setupSearchHandlers() {
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    if (searchInput && searchBtn) {
      searchInput.addEventListener('input', filterAndSortProducts);
      searchBtn.addEventListener('click', filterAndSortProducts);
    }
  }

  document.getElementById('sortSelect')?.addEventListener('change', filterAndSortProducts);
  document.getElementById('favOnlyToggle')?.addEventListener('change', filterAndSortProducts);
  [seriesFilter, inStockFilter].forEach(el =>
    el?.addEventListener("change", filterAndSortProducts)
  );

  fetch('/products')
    .then(res => res.json())
    .then(data => {
      allProducts = data;
      populateFilterOptions(data);
      filterAndSortProducts();
    });

  setupSearchHandlers();
}

// Слайдер
const slides = document.querySelector(".slides");
if (slides) {
  const totalSlides = slides.children.length;
  let index = 0;

  function showSlide(i) {
    index = (i + totalSlides) % totalSlides;
    slides.style.transform = `translateX(-${index * 100}%)`;
  }

  document.querySelector(".prev")?.addEventListener("click", () => showSlide(index - 1));
  document.querySelector(".next")?.addEventListener("click", () => showSlide(index + 1));
  setInterval(() => showSlide(index + 1), 5000);
}

// HTML включення
async function includeHTML(id, file) {
  const el = document.getElementById(id);
  const res = await fetch(file);
  if (res.ok) {
    el.innerHTML = await res.text();
    if (id === "header") {
      await startApp(); // запуск логіки тільки після завантаження хедера
    }
  }
}

includeHTML("header", "header.html");
includeHTML("footer", "footer.html");
// 🔐 Автоматичне оновлення шапки: Кабінет / Увійти
document.addEventListener("DOMContentLoaded", () => {
  const username = localStorage.getItem("username");
  const container = document.getElementById("user-links");

  if (container) {
    if (username) {
     container.innerHTML = `
        <a href="account.html">👤 ${username}</a>
        <a href="#" onclick="logout()">Вийти</a>
      `;
    } else {
      container.innerHTML = `<a href="login.html">Увійти</a>`;
   }
  }
});

function logout() {
  localStorage.removeItem("username");
  alert("Ви вийшли з акаунта.");
  location.href = "index.html";
}
