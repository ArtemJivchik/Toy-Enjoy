document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(window.location.search);
  const productId = Number(params.get("id"));

  if (!productId) {
    document.body.innerHTML = "<p>Не вказано ID товару.</p>";
    return;
  }

  try {
    const res = await fetch("/products");
    const products = await res.json();
    const product = products.find(p => p.id === productId);

    if (!product) {
      document.body.innerHTML = "<p>Товар не знайдено.</p>";
      return;
    }

    if (!Array.isArray(product.images)) {
      product.images = Array.isArray(product.image) ? product.image : [product.image];
    }

    document.getElementById("product-title").textContent = product.title;
    document.getElementById("product-price").textContent = product.price;
    document.getElementById("product-brand").textContent = product.brand;
    document.getElementById("product-series").textContent = product.series;
    document.getElementById("product-description").textContent = product.description;
    document.getElementById("product-stock").textContent = product.inStock ? "В наявності" : "Немає в наявності";

    const mainImage = document.getElementById("product-image");
    mainImage.src = `/images/${product.images[0]}`;
    mainImage.alt = product.title;

    const thumbnails = document.getElementById("thumbnails");
    thumbnails.innerHTML = '';
    product.images.forEach(img => {
      const thumb = document.createElement("img");
      thumb.src = `/images/${img}`;
      thumb.alt = "Мініатюра";
      thumb.classList.add("thumbnail");
      thumb.addEventListener("click", () => {
        mainImage.src = `/images/${img}`;
      });
      thumbnails.appendChild(thumb);
    });

    document.getElementById("addToCart").addEventListener("click", async () => {
      try {
        const response = await fetch("/add-to-cart", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: product.id })
        });

        if (response.ok) {
          alert("Товар додано до кошика!");
        } else {
          alert("Не вдалося додати товар.");
        }
      } catch (err) {
        console.error("Помилка додавання в кошик:", err);
      }
    });

  } catch (error) {
    console.error("Помилка при завантаженні товарів:", error);
    document.body.innerHTML = "<p>Не вдалося завантажити товар.</p>";
  }
});
