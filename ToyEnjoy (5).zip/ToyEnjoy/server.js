const express = require('express');
const path = require('path');
const fs = require('fs');
const DataWrapper = require('./utils/DataWrapper');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const dataWrapper = new DataWrapper(path.join(__dirname, 'data', 'products.json'));
const ordersPath = path.join(__dirname, 'data', 'orders.json');
const allOrdersPath = path.join(__dirname, 'data', 'all_orders.json');

app.get('/products', (req, res) => {
  const products = dataWrapper.getProducts();
  res.json(products);
});

app.post('/add-to-cart', (req, res) => {
  const { id } = req.body;
  const products = dataWrapper.getProducts();
  const product = products.find(p => p.id === Number(id));

  if (!product) {
    return res.status(404).json({ message: 'Товар не знайдено' });
  }

  try {
    const orders = JSON.parse(fs.readFileSync(ordersPath, 'utf-8'));
    orders.orders.push(product);
    fs.writeFileSync(ordersPath, JSON.stringify(orders, null, 2), 'utf-8');
    res.json({ message: 'Товар додано до кошика' });
  } catch (err) {
    console.error('Помилка при записі до файлу:', err);
    res.status(500).json({ message: 'Помилка при записі до файлу' });
  }
});

app.get('/cart', (req, res) => {
  try {
    const orders = JSON.parse(fs.readFileSync(ordersPath, 'utf-8'));
    res.json(orders.orders);
  } catch (err) {
    console.error('Помилка читання кошика:', err);
    res.status(500).json({ message: 'Помилка при завантаженні кошика' });
  }
});

app.post('/remove-from-cart', (req, res) => {
  const { id } = req.body;

  try {
    const data = JSON.parse(fs.readFileSync(ordersPath, 'utf8'));
    data.orders = data.orders.filter(order => order.id !== Number(id));
    fs.writeFileSync(ordersPath, JSON.stringify(data, null, 2), 'utf8');
    res.sendStatus(200);
  } catch (err) {
    console.error('Помилка при видаленні товару:', err);
    res.status(500).send('Помилка сервера');
  }
});

// ✅ НОВИЙ маршрут для оформлення замовлення
app.post('/checkout', (req, res) => {
  const userInfo = req.body;

  try {
    const currentCart = JSON.parse(fs.readFileSync(ordersPath, 'utf-8')).orders;

    const newOrder = {
      date: new Date().toISOString(),
      user: userInfo,
      items: currentCart
    };

    let allOrders = [];
    if (fs.existsSync(allOrdersPath)) {
      allOrders = JSON.parse(fs.readFileSync(allOrdersPath, 'utf-8'));
    }

    allOrders.push(newOrder);
    fs.writeFileSync(allOrdersPath, JSON.stringify(allOrders, null, 2), 'utf-8');

    // очищаємо поточний кошик
    fs.writeFileSync(ordersPath, JSON.stringify({ orders: [] }, null, 2), 'utf-8');

    res.sendStatus(200);
  } catch (err) {
    console.error('Помилка при оформленні замовлення:', err);
    res.status(500).json({ message: 'Помилка при оформленні замовлення' });
  }
});

app.get('/', (req, res) => {
  res.redirect('/index.html');
});
const usersPath = path.join(__dirname, 'data', 'users.json');

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  try {
    const users = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
    const user = users.find(u => u.username === username && u.password === password);

   if (user) {
     res.sendStatus(200); // логін успішний
    } else {
      res.sendStatus(401); // невірні дані
    }
  } catch (err) {
    console.error('Помилка логіна:', err);
    res.sendStatus(500);
  }
});

app.post('/register', (req, res) => {
  const { username, email, password } = req.body;

  try {
   const users = fs.existsSync(usersPath)
     ? JSON.parse(fs.readFileSync(usersPath, 'utf-8'))
   : [];

  const exists = users.some(u => u.username === username);

   if (exists) {
     return res.sendStatus(409); // вже існує
   }

    const newUser = {
      username,
      email,
      password, // ❗ пізніше — хешування
      orders: []
   };

    users.push(newUser);

    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf-8');
    res.sendStatus(201); // створено
  } catch (err) {
    console.error('Помилка реєстрації:', err);
    res.sendStatus(500);
  }
});

app.get('/user', (req, res) => {
const { username } = req.query;
if (!username) return res.sendStatus(400);

try {
 const users = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
const user = users.find(u => u.username === username);
if (!user) return res.sendStatus(404);

const allOrders = fs.existsSync(allOrdersPath)
 ? JSON.parse(fs.readFileSync(allOrdersPath, 'utf-8'))
    : [];

   const myOrders = allOrders.filter(o => o.user.username === username);

    res.json({
    email: user.email,
    orders: myOrders
  });
 } catch (err) {
  console.error("Помилка отримання юзера:", err);
   res.sendStatus(500);
  }
});

app.listen(PORT, () => {
  console.log(`Сервер запущено на http://localhost:${PORT}`);
});
