const express = require('express');
const path = require('path');
const fs = require('fs');
const DataWrapper = require('./utils/DataWrapper');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const dataWrapper = new DataWrapper(path.join(__dirname, 'data', 'products.json'));
const ordersPath = path.join(__dirname, 'data', 'orders.json');

app.get('/products', (req, res) => {
  const products = dataWrapper.getProducts();
  res.json(products);
});

app.post('/add-to-cart', (req, res) => {
  const { id } = req.body;
  const products = dataWrapper.getProducts();
  const product = products.find(p => p.id === Number(id));

  if (!product) {
    return res.status(404).json({ message: 'Товар не знайдено' });
  }

  try {
    const orders = JSON.parse(fs.readFileSync(ordersPath, 'utf-8'));
    orders.orders.push(product);
    fs.writeFileSync(ordersPath, JSON.stringify(orders, null, 2), 'utf-8');
    res.json({ message: 'Товар додано до кошика' });
  } catch (err) {
    console.error('Помилка при записі до файлу:', err);
    res.status(500).json({ message: 'Помилка при записі до файлу' });
  }
});

app.get('/cart', (req, res) => {
  try {
    const orders = JSON.parse(fs.readFileSync(ordersPath, 'utf-8'));
    res.json(orders.orders);
  } catch (err) {
    console.error('Помилка читання кошика:', err);
    res.status(500).json({ message: 'Помилка при завантаженні кошика' });
  }
});

app.post('/remove-from-cart', (req, res) => {
  const { id } = req.body;

  try {
    const data = JSON.parse(fs.readFileSync(ordersPath, 'utf8'));
    data.orders = data.orders.filter(order => order.id !== Number(id));
    fs.writeFileSync(ordersPath, JSON.stringify(data, null, 2), 'utf8');
    res.sendStatus(200);
  } catch (err) {
    console.error('Помилка при видаленні товару:', err);
    res.status(500).send('Помилка сервера');
  }
});

app.get('/', (req, res) => {
  res.redirect('/index.html');
});

app.listen(PORT, () => {
  console.log(`Сервер запущено на http://localhost:${PORT}`);
});
